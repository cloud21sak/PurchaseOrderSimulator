import base64
import boto3
import decimal
import json
import uuid

def lambda_handler(event, context):
    item = None
    dynamoDb = boto3.resource('dynamodb')
    purchaseOrdersTable = dynamoDb.Table('VarietyGiftOrders')
    decodedOrderRecordData = [base64.b64decode(record['kinesis']['data']) for record in event['Records']]
    deserializedData = [json.loads(decodedRecord) for decodedRecord in decodedOrderRecordData]

    with purchaseOrdersTable.batch_writer() as batchWriter:
        for item in deserializedData:
            if (item['Customer'].isdigit()):
                invoice = item['InvoiceNo']                
                customer = int(item['Customer'])
                orderDate = item['InvoiceDate']
                quantity = item['Quantity']
                description = item['Description']
                unitPrice = item['UnitPrice']
                country = item['Country'].rstrip()
                stockCode = item['StockCode']
            
                # Construct a unique sort key for this line item                
                orderID = uuid.uuid4().hex

                batchWriter.put_item(                        
                    Item = {
                                'CustomerID': decimal.Decimal(customer),
                                'OrderID': orderID,
                                'OrderDate': orderDate,
                                'Quantity': decimal.Decimal(quantity),
                                'UnitPrice': decimal.Decimal(unitPrice),
                                'Description': description,
                                'Country': country
                            }
                )